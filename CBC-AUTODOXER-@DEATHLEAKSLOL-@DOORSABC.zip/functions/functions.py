import string
import random
import json

import re

import ua_generator

def get_item_from_config(config_file="config/config.json", item=None):
    try:
        with open(config_file, "r") as f:
            config_data = json.load(f)
            item_details = config_data.get(item)
            if item_details:
                return item_details
            else:
                raise KeyError(f"{item} details not found in config file.")
    except FileNotFoundError:
        raise FileNotFoundError(f"Config file {config_file} not found.")
    except json.JSONDecodeError as json_error:
        raise ValueError(f"Error parsing JSON in config file: {json_error}")
    except KeyError as key_error:
        raise KeyError(f"Key error in config file: {key_error}")
    except Exception as e:
        raise RuntimeError(f"Error reading config file: {e}")

def extract_email(input_string):
    email_pattern = r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"
    emails = re.findall(email_pattern, input_string)
    if emails:
        return emails[0]
    else:
        return None

def extract_emails_from_file(file_path, domain_filter):
    emails = []
    counter = 0
    filter_skipped = 0
    global start_index
    start_index = 0
    
    with open(file_path, "r") as file:
        for line in file:
            counter += 1
            email = extract_email(line.strip())
            if email:
                if email.split("@")[1] in domain_filter:
                    emails.append(email)
                else:
                    filter_skipped += 1
    
    print(f"[~] Filtered out {filter_skipped} from your list {counter} of emails.\n")

    processed_file_path = "config/processed.txt"
    last_email = None
    
    try:
        with open(processed_file_path, "r") as processed_file:
            lines = processed_file.readlines()
            if lines:
                last_email = lines[-1].strip()
    except FileNotFoundError:
        pass
    
    if last_email and last_email in emails:
        response = input(f"[~] It is detected that you have ended off on email {last_email}. Would you like to continue from this? (yes/no): ").strip().lower()
        if response == "yes":
            start_index = emails.index(last_email) + 1
            emails = emails[start_index:]
        else:
            emails = []
    
    return emails, start_index

def write_mail_result(email, result_path, status):
    with open("config/processed.txt", "a+") as writer:
        get_email = extract_email(email)
        writer.write(get_email.lower() + "\n")
    with open(result_path + f"/{status}.txt", "a+") as writer:
        writer.write(email.lower() + "\n")
    
def print_words():
    print("""\033[34m
 _____      _ _      _         _            _                    
|___ /_   _(_) |    / \  _   _| |_ ___   __| | _____  _____ _ __ 
  |_ \ \ / / | |   / _ \| | | | __/ _ \ / _` |/ _ \ \/ / _ \ '__|
 ___) \ V /| | |  / ___ \ |_| | || (_) | (_| | (_) >  <  __/ |   
|____/ \_/ |_|_| /_/   \_\__,_|\__\___/ \__,_|\___/_/\_\___|_|   @doorsabc \033[0m\n""")
    

def generate_user_agent():
    ua = ua_generator.generate(platform=("windows"), browser=("chrome"))

    get_headers = ua.headers.get()
    return get_headers, get_headers.get("sec-ch-ua").split('"Google Chrome";v="')[1].replace('"', "")