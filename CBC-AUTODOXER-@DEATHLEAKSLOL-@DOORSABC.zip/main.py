from functools import partial
from bs4 import BeautifulSoup
import concurrent.futures
import tls_client
import logging
import time
import json
import sys
import os

from functions.functions import extract_emails_from_file, get_item_from_config, generate_user_agent, write_mail_result, print_words

class InfoFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return record.levelno == logging.INFO

file_handler = logging.FileHandler('config/dox.log')
file_handler.setLevel(logging.DEBUG)
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(logging.DEBUG)
console_handler.addFilter(InfoFilter())
formatter = logging.Formatter('%(levelname)s %(module)s - %(funcName)s: %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

logger.addHandler(file_handler)
logger.addHandler(console_handler)

global top_handler
top_handler = 0

global total_length
total_length = 0

def get_house_value(
    tls_session: tls_client.Session,
    details_link: str,
    get_proxy: str,
    created_header: dict[str, str]
) -> str:
    try:
        fetch_details = tls_session.get(
            details_link, headers=created_header, proxy=get_proxy
        ).text

        if "Just a moment" in fetch_details:
            return get_house_value(tls_session, details_link, get_proxy, created_header)
        else:
            try:
                get_house_value = (
                    "$" + fetch_details.split("Estimated Value")[1].split("$")[1].split("</strong")[0]
                )
                return get_house_value
            except IndexError as e:
                return "N/A"
    except Exception as e:
        logging.error(f"Exception occurred in get_house_value: {str(e)}")

def attempt_dox(
    email: str,
    get_proxy: str,
    log_path: str
) -> None:
    global top_handler, total_length
    try:
        created_header, get_version = generate_user_agent()
        session = tls_client.Session(
            client_identifier="chrome_" + get_version,
            random_tls_extension_order=True
        )

        session.headers = created_header

        response = session.get(
            "https://www.cyberbackgroundchecks.com/email/" + email.replace("@", "_."), headers=created_header, proxy=get_proxy
        )

        if "Just a moment" in response.text:
            logging.warning(f"Cloudflare block detected {email} - Retrying")
            attempt_dox(email, get_proxy, log_path)
        else:
            top_handler += 1
            script_tags = BeautifulSoup(response.text, 'html.parser').find_all('script', type='application/ld+json')

            if script_tags:
                json_ld = json.loads(script_tags[0].string)

                if isinstance(json_ld, list):
                    if json_ld[0].get("name") is not None:
                        get_name = json_ld[0].get("name")
                        get_number = json_ld[0].get("telephone")
                        get_address = json_ld[0].get("address")[0].get("streetAddress")
                        get_age = response.text.split("<span class=\"age\">")[1].split("</span>")[0]
                        get_more_details = json_ld[0].get("@id")
                        if "cyberbackgroundchecks" in get_more_details:
                            if isinstance(get_number, list):
                                get_number = json_ld[0].get("telephone")[0]
                            
                            house_value = get_house_value(session, get_more_details, get_proxy, created_header)
                            make_format = f"{email} / Name: {get_name} / Phone number: {get_number} / Age: {get_age} / House address: {get_address} ~ {house_value}"
                            write_mail_result(make_format, log_path, "doxed")
                            logging.info(f"{make_format} / Line: ({top_handler}/{total_length})")
                else:
                    logging.warning(f"Failed to gather dox on {email}")
                    write_mail_result(email, log_path, "failed")
    except Exception as e:
        logging.error(f"Exception occurred for email {email}: {str(e)} - Retrying")
        attempt_dox(email, get_proxy, log_path)

def main():
    global total_length, top_handler
    proxy = get_item_from_config(item="proxy")
    log_path = get_item_from_config(item="log_path")
    file_path = get_item_from_config(item="file_path")
    domain_filter = None
    with open(file_path, "r+") as reader:
        get_length = len(reader.readlines())
        total_length = get_length
    try:
        print_words()
        ask_max_threads = int(input("[~] How many threads would you like to run this on? "))
        
    except ValueError:
        print("Invalid input for threads. Exiting.")
        return
    
    ask_email_filter = str(input("[~] Would you like to use the email filter configuration? (yes/no) ")).lower()
    if ask_email_filter == "yes":
        domain_filter = get_item_from_config(item="domain_filter")

    if not (0 < ask_max_threads <= 750):
        print("Invalid number of threads. Exiting.")
        return

    emails, start_index = extract_emails_from_file(file_path, domain_filter)

    if start_index != []:
        top_handler = start_index
    
    print("[~] Starting Autodoxer\n")

    with concurrent.futures.ThreadPoolExecutor(max_workers=ask_max_threads) as executor:
        futures = [executor.submit(partial(attempt_dox, email, proxy, log_path)) for email in emails]

        for future in concurrent.futures.as_completed(futures):
            try:
                future.result()
            except Exception as exc:
                logging.error(f"(Line 116) {repr(exc)}")

main()